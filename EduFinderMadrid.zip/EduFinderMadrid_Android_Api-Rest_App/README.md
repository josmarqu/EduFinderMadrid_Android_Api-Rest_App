# EduFinderMadrid
An Android Application that calls the api-rest datos.madrid.es using RetroFit REST client to search for Universities, colleges, halls of residence, residences colleges, university residences and other educational centers in the Community of Madrid.
