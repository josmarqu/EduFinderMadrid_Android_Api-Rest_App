package app.edufindermadrid.dialog;

public interface OnDialogListener {
}
