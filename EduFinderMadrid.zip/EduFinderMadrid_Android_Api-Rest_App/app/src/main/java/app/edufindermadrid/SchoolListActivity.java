package app.edufindermadrid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SchoolListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_list);
    }
}