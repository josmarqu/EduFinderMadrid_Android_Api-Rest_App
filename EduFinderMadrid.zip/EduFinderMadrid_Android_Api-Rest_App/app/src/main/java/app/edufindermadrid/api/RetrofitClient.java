package app.edufindermadrid.api;

public class RetrofitClient {
}
