package app.edufindermadrid.api;

public interface APIRestService {
}
